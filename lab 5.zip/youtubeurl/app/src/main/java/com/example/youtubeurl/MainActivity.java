package com.example.youtubeurl;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.annotation.SuppressLint;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements StartActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);// Set the layout for this activity

        // Suppress lint warnings for missing ID and local suppression
        // Find the Button in the layout with the ID 'openYoutubeButton'
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) Button openYoutubeButton = findViewById(R.id.openYoutubeButton);
        // Set an OnClickListener for the button
        openYoutubeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openYoutubeUrl();
            } // Call the method to open YouTube URL when the button is clicked
        });
    }
    // Method to open a YouTube URL
    private void openYoutubeUrl() {
        String youtubeUrl = "https://www.youtube.com/watch?v=Kn6QA4ytKRs";
        // Create an Intent to view the YouTube URL
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(youtubeUrl));
        //dispalying data to the user
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        // Set the package to ensure the intent opens in the YouTube app
        intent.setPackage("com.google.android.youtube");
        try {
            startActivity(intent);// Try to start the activity with the YouTube app
        } catch (Exception e) {
            // If YouTube app is not installed, open URL in a web browser
            intent.setPackage(null);// Make sure the intent is implicit
            startActivity(intent);
        }
    }
}