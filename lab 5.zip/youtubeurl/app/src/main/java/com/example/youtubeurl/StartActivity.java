package com.example.youtubeurl;

public interface StartActivity {
}
